# AI Skin Intelligence & Personalized Skincare Planner

This package contains the working frontend plus backend scaffolding aligned with the supplied Infosys Springboard Module 1 and Module 3 guides.

## Included project flow

Home → Login → Role Dashboard → Skin Scan → Image Upload/Camera → Assessment Test → Skin Health Score + AI confidence → Recommended products with images/prices → Consultant recommendation → Care Plan.

## Module 1 alignment
- User registration and login
- BCrypt password hashing in the FastAPI backend
- JWT authentication
- Role-based access control
- User profile GET/PUT APIs
- PostgreSQL persistence

The supplied Module 1 guide also specifies Google OAuth2. The Google login button was intentionally removed from the current project because you previously requested its removal. OAuth can be added later without changing the JWT/RBAC design.

## Module 3 alignment
- Skin assessment
- Concern identification and prioritization
- Skin health score
- Risk-factor analysis
- Assessment history
- REST APIs for create/list/detail/update-ready/delete/history/score/risks
- PostgreSQL models for SkinAssessment, SkinConcern and RiskFactor

The browser UI currently performs a rule-based assessment for presentation; it is explicitly non-diagnostic. The backend exposes the corresponding assessment API structure described in Module 3.

## Run the frontend
Open `index.html` for the UI. For camera access, use HTTPS or localhost rather than a `file://` URL.

## Run the backend
1. Install PostgreSQL and create database `ai_skin`.
2. In `backend/`, install `requirements.txt`.
3. Set `DATABASE_URL` and `SECRET_KEY`.
4. Run: `uvicorn main:app --reload`
5. API docs: `http://localhost:8000/docs`

The original supplied guides are preserved under `docs/` for submission/reference.
