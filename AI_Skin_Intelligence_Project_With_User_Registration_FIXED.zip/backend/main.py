import os
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr
from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, relationship, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://postgres:postgres@localhost:5432/ai_skin")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = 60

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(30), default="USER")
    provider: Mapped[str] = mapped_column(String(20), default="LOCAL")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SkinAssessment(Base):
    __tablename__ = "skin_assessments"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    assessment_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    skin_health_score: Mapped[float] = mapped_column(Float)
    overall_condition: Mapped[str] = mapped_column(String(120))
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    concerns: Mapped[list["SkinConcern"]] = relationship(back_populates="assessment", cascade="all, delete-orphan")
    risks: Mapped[list["RiskFactor"]] = relationship(back_populates="assessment", cascade="all, delete-orphan")

class SkinConcern(Base):
    __tablename__ = "skin_concerns"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey("skin_assessments.id"), index=True)
    concern_name: Mapped[str] = mapped_column(String(100))
    severity: Mapped[str] = mapped_column(String(30))
    priority: Mapped[int] = mapped_column(Integer)
    assessment: Mapped[SkinAssessment] = relationship(back_populates="concerns")

class RiskFactor(Base):
    __tablename__ = "risk_factors"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey("skin_assessments.id"), index=True)
    risk_name: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(Text)
    risk_level: Mapped[str] = mapped_column(String(30))
    assessment: Mapped[SkinAssessment] = relationship(back_populates="risks")

Base.metadata.create_all(bind=engine)

class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str
    role: str = "USER"

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class ProfileUpdate(BaseModel):
    name: Optional[str] = None

class AssessmentCreate(BaseModel):
    skin_health_score: float
    overall_condition: str
    notes: Optional[str] = None
    concerns: list[dict] = []
    risks: list[dict] = []

app = FastAPI(title="AI Skin Intelligence API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

def db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()

def make_token(user: User):
    exp = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_MINUTES)
    return jwt.encode({"id": user.id, "email": user.email, "role": user.role, "exp": exp}, SECRET_KEY, algorithm=ALGORITHM)

def current_user(token: str = "", session: Session = Depends(db)):
    from fastapi.security import OAuth2PasswordBearer
    # Accept the standard Bearer header through a lightweight dependency.
    raise HTTPException(status_code=500, detail="Use the bearer_user dependency")

from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
bearer = HTTPBearer(auto_error=False)

def bearer_user(credentials: HTTPAuthorizationCredentials = Depends(bearer), session: Session = Depends(db)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Authorization token required")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload.get("id"))
    except (JWTError, TypeError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = session.get(User, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

def require_roles(*roles):
    def dep(user: User = Depends(bearer_user)):
        if user.role not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        return user
    return dep

@app.get("/")
def root():
    return {"name": "AI Skin Intelligence API", "status": "running"}

@app.post("/api/auth/register")
def register(data: RegisterRequest, session: Session = Depends(db)):
    if session.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=409, detail="Email already registered")
    role = data.role.upper()
    if role not in {"USER", "WELLNESS_COACH", "ADMIN", "DOCTOR", "RECRUITER"}:
        raise HTTPException(status_code=400, detail="Invalid role")
    user = User(name=data.name, email=data.email, password=pwd_context.hash(data.password), role=role, provider="LOCAL")
    session.add(user); session.commit(); session.refresh(user)
    return {"message": "Registration successful", "id": user.id, "role": user.role}

@app.post("/api/auth/login")
def login(data: LoginRequest, session: Session = Depends(db)):
    user = session.query(User).filter(User.email == data.email).first()
    if not user or not pwd_context.verify(data.password, user.password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"access_token": make_token(user), "token_type": "bearer", "role": user.role}

@app.get("/api/profile")
def profile(user: User = Depends(bearer_user)):
    return {"id": user.id, "name": user.name, "email": user.email, "role": user.role, "provider": user.provider}

@app.put("/api/profile")
def update_profile(data: ProfileUpdate, session: Session = Depends(db), user: User = Depends(bearer_user)):
    if data.name:
        user.name = data.name
    session.commit(); session.refresh(user)
    return {"message": "Profile updated", "name": user.name}

@app.post("/assessment")
def create_assessment(data: AssessmentCreate, session: Session = Depends(db), user: User = Depends(bearer_user)):
    score = max(0, min(100, data.skin_health_score))
    assessment = SkinAssessment(user_id=user.id, skin_health_score=score, overall_condition=data.overall_condition, notes=data.notes)
    session.add(assessment); session.flush()
    for i, item in enumerate(sorted(data.concerns, key=lambda x: x.get("priority", 999))):
        assessment.concerns.append(SkinConcern(concern_name=item.get("concern_name", "Unknown"), severity=item.get("severity", "Moderate"), priority=item.get("priority", i+1)))
    for item in data.risks:
        assessment.risks.append(RiskFactor(risk_name=item.get("risk_name", "General"), description=item.get("description", ""), risk_level=item.get("risk_level", "Low")))
    session.commit(); session.refresh(assessment)
    return {"id": assessment.id, "skin_health_score": assessment.skin_health_score, "overall_condition": assessment.overall_condition}

@app.get("/assessment")
def get_assessments(session: Session = Depends(db), user: User = Depends(bearer_user)):
    rows = session.query(SkinAssessment).filter(SkinAssessment.user_id == user.id).order_by(SkinAssessment.assessment_date.desc()).all()
    return [{"id": a.id, "assessment_date": a.assessment_date, "skin_health_score": a.skin_health_score, "overall_condition": a.overall_condition} for a in rows]

@app.get("/assessment/{assessment_id}")
def get_assessment(assessment_id: int, session: Session = Depends(db), user: User = Depends(bearer_user)):
    a = session.get(SkinAssessment, assessment_id)
    if not a or a.user_id != user.id:
        raise HTTPException(status_code=404, detail="Assessment not found")
    return {"id": a.id, "score": a.skin_health_score, "condition": a.overall_condition,
            "notes": a.notes, "concerns":[c.__dict__ | {"_sa_instance_state": None} for c in a.concerns],
            "risks":[r.__dict__ | {"_sa_instance_state": None} for r in a.risks]}

@app.get("/assessment/history")
def assessment_history(session: Session = Depends(db), user: User = Depends(bearer_user)):
    return get_assessments(session, user)

@app.get("/assessment/score")
def assessment_score(session: Session = Depends(db), user: User = Depends(bearer_user)):
    a = session.query(SkinAssessment).filter(SkinAssessment.user_id == user.id).order_by(SkinAssessment.assessment_date.desc()).first()
    return {"score": a.skin_health_score if a else None}

@app.get("/assessment/risks")
def assessment_risks(session: Session = Depends(db), user: User = Depends(bearer_user)):
    rows = session.query(RiskFactor).join(SkinAssessment).filter(SkinAssessment.user_id == user.id).all()
    return [{"risk_name": r.risk_name, "description": r.description, "risk_level": r.risk_level} for r in rows]

@app.delete("/assessment/{assessment_id}")
def delete_assessment(assessment_id: int, session: Session = Depends(db), user: User = Depends(bearer_user)):
    a = session.get(SkinAssessment, assessment_id)
    if not a or a.user_id != user.id:
        raise HTTPException(status_code=404, detail="Assessment not found")
    session.delete(a); session.commit()
    return {"message": "Assessment deleted"}
