CREATE DATABASE ai_skin;
-- The FastAPI backend creates the Users, SkinAssessment, SkinConcern and RiskFactor tables automatically.
-- This file documents the expected PostgreSQL database entry point.
